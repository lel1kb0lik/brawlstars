﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;



namespace Brawl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
            form2.FormClosed += (s, args) => this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
            form3.FormClosed += (s, args) => this.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
            form4.FormClosed += (s, args) => this.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            this.Hide();
            form5.FormClosed += (s, args) => this.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
            this.Hide();
            form6.FormClosed += (s, args) => this.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
            this.Hide();
            form7.FormClosed += (s, args) => this.Show();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
            this.Hide();
            form8.FormClosed += (s, args) => this.Show();

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.Show();
            this.Hide();
            form9.FormClosed += (s, args) => this.Show();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();
            form10.Show();
            this.Hide();
            form10.FormClosed += (s, args) => this.Show();

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form11 form11 = new Form11();
            form11.Show();
            this.Hide();
            form11.FormClosed += (s, args) => this.Show();

        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form12 form12 = new Form12();
            form12.Show();
            this.Hide();
            form12.FormClosed += (s, args) => this.Show();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form13 form13 = new Form13();
            form13.Show();
            this.Hide();
            form13.FormClosed += (s, args) => this.Show();

        }
        private void button13_Click(object sender, EventArgs e)
        {
            Form14 form14 = new Form14();
            form14.Show();
            this.Hide();
            form14.FormClosed += (s, args) => this.Show();
        }
        // ★★★★ ДОБАВЛЯЕМ ЭТОТ КОД ТОЛЬКО ДЛЯ КНОПОК 6-13 ★★★★

        private void SetupParallelogramButtons()
        {
            // Массив только кнопок с 6 по 13
            Button[] buttons = { button6, button7, button8, button9, button10, button11, button12};

            // Настройка внешнего вида кнопок
            foreach (var button in buttons)
            {
                // Убираем стандартное оформление
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderSize = 0;
                button.BackColor = Color.Transparent;
                button.ForeColor = Color.White;
                button.Font = new Font("Arial", 10, FontStyle.Bold);
                // Устанавливаем размер кнопок
                button.Size = new Size(120, 50);

                // Добавляем кастомную отрисовку
                button.Paint += DrawParallelogramButton;
            }
        }

        private void DrawParallelogramButton(object sender, PaintEventArgs e)
        {
            Button button = sender as Button;
            if (button == null) return;

            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Создаем путь для параллелепипеда
            using (GraphicsPath path = new GraphicsPath())
            {
                // Точки для параллелепипеда (наклон 20 пикселей)
                Point[] points = {
                    new Point(20, 0),                    // Верхний левый (смещен вправо)
                    new Point(button.Width, 0),          // Верхний правый
                    new Point(button.Width - 20, button.Height), // Нижний правый (смещен влево)
                    new Point(0, button.Height)          // Нижний левый
                };

                path.AddPolygon(points);

                // Градиентная заливка
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    button.ClientRectangle,
                    Color.FromArgb(255, 70, 130, 180),   // Светло-голубой
                    Color.FromArgb(255, 30, 90, 140),    // Темно-голубой
                    LinearGradientMode.ForwardDiagonal))
                {
                    g.FillPath(brush, path);
                }

                // Обводка
                using (Pen borderPen = new Pen(Color.FromArgb(255, 20, 60, 100), 2))
                {
                    g.DrawPath(borderPen, path);
                }

                // Рисуем текст с небольшим наклоном
                if (!string.IsNullOrEmpty(button.Text))
                {
                    // Сохраняем оригинальную трансформацию
                    Matrix oldMatrix = g.Transform;

                    // Применяем небольшой наклон к тексту
                    Matrix textMatrix = g.Transform;
                    textMatrix.Shear(-0.1f, 0f); // Наклон по X
                    g.Transform = textMatrix;

                    // Рисуем текст
                    StringFormat sf = new StringFormat();
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;

                    using (SolidBrush textBrush = new SolidBrush(button.ForeColor))
                    {
                        // Смещаем текст из-за трансформации
                        Rectangle textRect = new Rectangle(5, 0, button.Width, button.Height);
                        g.DrawString(button.Text, button.Font, textBrush, textRect, sf);
                    }

                    // Восстанавливаем трансформацию
                    g.Transform = oldMatrix;
                }
            }
        }
    }
}




    

